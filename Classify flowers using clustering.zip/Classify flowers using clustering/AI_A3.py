import os
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans, DBSCAN
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications import VGG16
from tensorflow.keras.applications.vgg16 import preprocess_input
from tensorflow.keras.models import Model
from sklearn.metrics import adjusted_rand_score
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, homogeneity_score

base_model = VGG16(weights='imagenet', include_top=False)
output = base_model.output
feature_extraction_model = Model(inputs=base_model.input, outputs=output)

csv_file = 'flower_labels.csv'
df = pd.read_csv(csv_file)
labels = df['label'].values

all_features = []

images_dir = 'C:\\Users\\a\\Desktop\\AI-A3\\flower_images'
for filename in os.listdir(images_dir):
    img_path = os.path.join(images_dir, filename)
    img = image.load_img(img_path, target_size=(224, 224))  # resize
    x = image.img_to_array(img)  # save features as numpy arr
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    features = feature_extraction_model.predict(x)
    all_features.append(features.reshape(-1))  # Flatten features

all_features = np.array(all_features)

num_clusters = 4
kmeans = KMeans(n_clusters=num_clusters, random_state=42)
cluster_labels_kmeans = kmeans.fit_predict(all_features)

dbscan = DBSCAN(eps=600, min_samples=2)
cluster_labels_dbscan = dbscan.fit_predict(all_features)

evaluation_df = pd.DataFrame({'label': labels,
                              'cluster_kmeans': cluster_labels_kmeans,
                              'cluster_dbscan': cluster_labels_dbscan})


pca = PCA(n_components=2)
reduced_features = pca.fit_transform(all_features)
evaluation_df['PCA1'] = reduced_features[:, 0]
evaluation_df['PCA2'] = reduced_features[:, 1]

plt.figure(figsize=(12, 6))

plt.subplot(1, 2, 1)
for cluster in range(num_clusters):
    cluster_data = evaluation_df[evaluation_df['cluster_kmeans'] == cluster]
    plt.scatter(cluster_data['PCA1'],
                cluster_data['PCA2'], label=f'Cluster {cluster}')
plt.title('K-means Clustering Visualization using PCA')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.legend()

plt.subplot(1, 2, 2)
unique_clusters_dbscan = np.unique(cluster_labels_dbscan)
for cluster in unique_clusters_dbscan:
    if cluster == -1:  # Noise points
        cluster_data = evaluation_df[evaluation_df['cluster_dbscan'] == cluster]
        plt.scatter(cluster_data['PCA1'], cluster_data['PCA2'], label=f'Noise')
    else:
        cluster_data = evaluation_df[evaluation_df['cluster_dbscan'] == cluster]
        plt.scatter(cluster_data['PCA1'],
                    cluster_data['PCA2'], label=f'Cluster {cluster}')
plt.title('DBSCAN Clustering Visualization using PCA')
plt.xlabel('PCA Component 1')
plt.ylabel('PCA Component 2')
plt.legend()

plt.show()

wcss = []  # Within-cluster sum of squares
for k in range(1, 11):
    kmeans = KMeans(n_clusters=k)
    kmeans.fit(all_features)
    wcss.append(kmeans.inertia_)  # Save the within-cluster sum of squares

plt.figure(figsize=(8, 6))
plt.plot(range(1, 11), wcss, marker='o', linestyle='-', color='b')
plt.title('Elbow Method for Optimal k')
plt.xlabel('Number of Clusters (k)')
plt.ylabel('Within-Cluster Sum of Squares (WCSS)')
plt.xticks(range(1, 11))
plt.grid(True)
plt.show()


kmeans = KMeans(n_clusters=num_clusters, random_state=42)
cluster_labels_kmeans = kmeans.fit_predict(all_features)

dbscan = DBSCAN(eps=1400, min_samples=2)
cluster_labels_dbscan = dbscan.fit_predict(all_features)

# Compute Silhouette Score for KMeans
silhouette_avg_kmeans = silhouette_score(all_features, cluster_labels_kmeans)
print(f"For KMeans, the average silhouette_score is : {silhouette_avg_kmeans}")

# Compute Silhouette Score for DBSCAN
silhouette_avg_dbscan = silhouette_score(all_features, cluster_labels_dbscan)
print(f"For DBSCAN, the average silhouette_score is : {silhouette_avg_dbscan}")

# Compute Homogeneity for KMeans
homogeneity_kmeans = homogeneity_score(labels, cluster_labels_kmeans)
print(f"For KMeans, the homogeneity_score is : {homogeneity_kmeans}")

# Compute Homogeneity for DBSCAN
homogeneity_dbscan = homogeneity_score(labels, cluster_labels_dbscan)
print(f"For DBSCAN, the homogeneity_score is : {homogeneity_dbscan}")
