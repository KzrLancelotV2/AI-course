import pandas as pd
import random
import numpy as np


def initialize_population(pop_size, min_num_of_snacks, max_num_of_snacks, df):
    population = []
    for _ in range(0, pop_size):
        chromosome = [0] * len(df)
        num_of_items = random.randint(min_num_of_snacks, max_num_of_snacks)
        chosen_items_index = random.sample(range(len(df)), num_of_items)
        for item_index in chosen_items_index:
            weight_of_each_item = random.uniform(
                0, df.loc[item_index]['Available Weight'])
            chromosome[item_index] = weight_of_each_item
        population.append(chromosome)
    return population


def calculate_fitnesses(population, max_weight, min_value, df):
    fitnesses = []
    total_fitness = 0
    for chromosome in population:
        fitness = calc_fitness(chromosome, max_weight, min_value, df)
        fitnesses.append(fitness)
        total_fitness += fitness
    return fitnesses, total_fitness


def calc_fitness(chromosome, max_weight, min_value, df):
    total_weight = 0
    total_value = 0
    for item_index, item_weight in enumerate(chromosome):
        total_weight += item_weight
        total_value += (item_weight / df.loc[item_index]
                        ['Available Weight']) * df.loc[item_index]['Value']
    if total_weight > max_weight or total_value < min_value:
        fitness = 0.1
    else:
        fitness = total_value
    return fitness


def mutate(chromosome, mutation_rate, df):
    for i in range(len(chromosome)):
        if random.random() < mutation_rate:
            chromosome[i] = random.uniform(0, df.loc[i]['Available Weight'])
    return chromosome


def create_new_population(population, fitnesses, pop_size, elites_size, mating_chance):
    new_population = []
    population_np = np.array(population)
    fitnesses_np = np.array(fitnesses)
    sorted_indices = np.argsort(fitnesses_np)[::-1]
    sorted_population = population_np[sorted_indices]
    elite_population = sorted_population[:int(elites_size)].tolist()
    new_population.extend(elite_population)

    for _ in range(0, (pop_size // 2) - len(elite_population)):
        chosen_chromosomes = random.choices(
            population, weights=mating_chance, k=2)
        child1 = chosen_chromosomes[0][:len(
            df)//2] + chosen_chromosomes[1][len(df)//2:]
        child2 = chosen_chromosomes[1][:len(
            df)//2] + chosen_chromosomes[0][len(df)//2:]
        child1 = mutate(child1, mutation_rate, df)
        child2 = mutate(child2, mutation_rate, df)
        new_population.append(child1)
        new_population.append(child2)
    return new_population


def run_genetic_algorithm(num_of_generations, pop_size, elites_size, mutation_rate, max_weight, min_value, min_num_of_snacks, max_num_of_snacks, df):
    population = initialize_population(
        pop_size, min_num_of_snacks, max_num_of_snacks, df)
    for _ in range(num_of_generations):
        fitnesses, total_fitness = calculate_fitnesses(
            population, max_weight, min_value, df)
        mating_chance = [fitness / total_fitness for fitness in fitnesses]
        population = create_new_population(
            population, fitnesses, pop_size, elites_size, mating_chance)

    fitnesses, _ = calculate_fitnesses(population, max_weight, min_value, df)
    population_np = np.array(population)
    fitnesses_np = np.array(fitnesses)
    sorted_indices = np.argsort(fitnesses_np)[::-1]
    sorted_population = population_np[sorted_indices]
    return sorted_population.tolist()


max_weight = int(input())
min_value = int(input())
allowed_num_of_snacks_str = input().split(' ')
min_num_of_snacks = int(allowed_num_of_snacks_str[0])
max_num_of_snacks = int(allowed_num_of_snacks_str[1])
num_of_generations = 50
pop_size = 1500
elites_size = 0.1 * pop_size
mutation_rate = 0.05
df = pd.read_csv('snacks.csv')

final_population = run_genetic_algorithm(
    num_of_generations, pop_size, elites_size,
    mutation_rate, max_weight, min_value, min_num_of_snacks, max_num_of_snacks, df)

best_chromosome = final_population[0]
total_weight = 0
total_value = 0
for i in range(len(best_chromosome)):
    if best_chromosome[i] > 0:
        print(f"{df.loc[i]['Snack']}: {best_chromosome[i]}")
        total_weight += best_chromosome[i]
        total_value += (best_chromosome[i] / df.loc[i]
                        ['Available Weight']) * df.loc[i]['Value']
print(f"Total Weight: {total_weight}")
print(f"Total Value: {total_value}")
